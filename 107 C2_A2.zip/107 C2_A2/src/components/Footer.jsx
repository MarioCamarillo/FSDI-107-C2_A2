import "./footer_other.css";

function Footer(){
    return (
        <div className="footer_other">
            <p>This is the footer of the page</p>
        </div>
    );
}

export default Footer;